var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","b8088c53-5096-4e30-99f3-ea03db5b7d33","69855e46-53f6-4ac5-9497-c80dc661daa0","f8c4b211-21ad-4e44-921c-af052b5c09df","a4fb0314-1c32-4c9c-9610-34c63583e039","ba879d18-63f0-4b84-b27e-e24ceecf93ee","7097bac7-97fc-4f78-ac22-d66727708765"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"I6ivbW_YTtbe1le4_o9I2bn7qvhHJRS_","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"FRRbQiPdTNJX85Y6aO8jQ0EzbVd0yB5G","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"e","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"en","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"ene","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"","sourceUrl":null,"frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":12,"version":"v9W0Bi4LOBoaBy5x1mhpktp3AF7724T2","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/c26b6449-0b6c-4483-8486-107c0091c26e.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"w","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"csLTBbqWlGRj5TvmFEo0wnwcIaGTIVLw","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"b8088c53-5096-4e30-99f3-ea03db5b7d33":{"name":"f","sourceUrl":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png"},"69855e46-53f6-4ac5-9497-c80dc661daa0":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/i.TOUie12cy0KbasjKdp6IWoFSTZDYCk/category_animals/animalhead_fox.png","frameSize":{"x":306,"y":316},"frameCount":1,"looping":true,"frameDelay":2,"version":"i.TOUie12cy0KbasjKdp6IWoFSTZDYCk","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":306,"y":316},"rootRelativePath":"assets/api/v1/animation-library/gamelab/i.TOUie12cy0KbasjKdp6IWoFSTZDYCk/category_animals/animalhead_fox.png"},"f8c4b211-21ad-4e44-921c-af052b5c09df":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/FV2Q8anR6u3sdXbNX.MvEmKJQex4ZvPV/category_animals/animalhead_snake_2.png","frameSize":{"x":300,"y":386},"frameCount":1,"looping":true,"frameDelay":2,"version":"FV2Q8anR6u3sdXbNX.MvEmKJQex4ZvPV","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":386},"rootRelativePath":"assets/api/v1/animation-library/gamelab/FV2Q8anR6u3sdXbNX.MvEmKJQex4ZvPV/category_animals/animalhead_snake_2.png"},"a4fb0314-1c32-4c9c-9610-34c63583e039":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV/category_animals/animalhead_lion.png","frameSize":{"x":400,"y":380},"frameCount":1,"looping":true,"frameDelay":2,"version":"PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":380},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV/category_animals/animalhead_lion.png"},"ba879d18-63f0-4b84-b27e-e24ceecf93ee":{"name":"judy","sourceUrl":null,"frameSize":{"x":302,"y":386},"frameCount":1,"looping":true,"frameDelay":12,"version":"sQX9XeqgZqn5_FBXNwfsqIOKBqty1JqL","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":302,"y":386},"rootRelativePath":"assets/ba879d18-63f0-4b84-b27e-e24ceecf93ee.png"},"7097bac7-97fc-4f78-ac22-d66727708765":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":60,"version":"OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// judy hoops é uma coelha que quer ser uma policial em zootopia
// mais ela tem que enfrentar predadores infectados para provar que pode ser uma policial

//precione "w,a,s,d" para andar e "espaço" para correr
// "jogo inspirado no filme da disney zootopia"



var b = createSprite(200,200);
 b.setAnimation("b")
var judy = createSprite(200,345,200,345)
judy.shapeColor="red"

var enemy1 = createSprite(200,250,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var net = createSprite(200,5,400,20)
net.shapeColor="red"

var goal =0;
var death = 0

judy.setAnimation("judy");
judy.scale=.1;
enemy1.setAnimation("enemy");
enemy1.scale=.2;
enemy2.setAnimation("enemy2");
enemy2.scale=.2;
enemy3.setAnimation("enemy3");
enemy3.scale=.2;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(-10,0);
enemy3.setVelocity(-10,0);


function draw() {
  
//plano de fundo(b);

createEdgeSprites()


judy.bounceOff(edges)

enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown("w")){
  judy.y=judy.y-5
}
if(keyDown("space")){
  judy.y=judy.y-5
}

if(keyDown("s")){
  judy.y=judy.y+5
}

if(keyDown("a")){
  judy.x=judy.x-5
}

if(keyDown("d")){
  judy.x=judy.x+5
}

if(judy.isTouching(enemy1)|| judy.isTouching(enemy2)|| judy.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  judy.x=200
  judy.y=350
  death = death+1
}
if(judy.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  judy.x=200
  judy.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Objetivos:"+goal,320,350);
  
  
textSize(20)
  fill("blue")
  text("mortes:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
